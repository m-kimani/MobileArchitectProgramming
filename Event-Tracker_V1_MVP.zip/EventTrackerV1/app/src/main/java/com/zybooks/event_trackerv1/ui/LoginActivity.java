package com.zybooks.event_trackerv1.ui;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.zybooks.event_trackerv1.R;
import com.zybooks.event_trackerv1.ui.database.UserEventDatabase;

public class LoginActivity extends AppCompatActivity {

    private EditText textUsername, textPassword;
    private Button loginButton, registerButton;
    private UserEventDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        // Used to hide the action bar
        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }
        db = new UserEventDatabase(this);

        textUsername = findViewById(R.id.username_editText);
        textPassword = findViewById(R.id.password_editText);
        loginButton = findViewById(R.id.login_button);
        registerButton = findViewById(R.id.create_user_button);
        registerButton.setOnClickListener(view -> register());
        loginButton.setOnClickListener(view -> login());
    }

    // Used to create a new user account with the credentials provided by the user when the 'create new user' buttton is clicked
    private void register() {
        String username = textUsername.getText().toString();
        String password = textPassword.getText().toString();

        if (db.registerUser(username, password)) {
            Toast.makeText(this, "Account Created", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Username already exists", Toast.LENGTH_SHORT).show();
        }
    }

    // Used to check user entered credentials against the database to authenticate the user after clicking 'login' button
    private void login() {
        String username = textUsername.getText().toString();
        String password = textPassword.getText().toString();
        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Enter username and password", Toast.LENGTH_SHORT).show();
            return;
        }

        boolean validLogin = db.checkLogin(username, password);

        if(validLogin) {
            int userId = db.getUserId(username, password);

            if (userId == -1) {
                Toast.makeText(this, "Invalid Login. Please try again or select 'Create New User'.", Toast.LENGTH_SHORT).show();
                return;
            }
            Intent intent = new Intent(this, EventActivity.class);
            intent.putExtra("USER_ID", userId);
            startActivity(intent);
        } else {
            Toast.makeText(this, "Invalid Login. Please try again or select 'Create New User'.", Toast.LENGTH_SHORT).show();
        }
    }
}