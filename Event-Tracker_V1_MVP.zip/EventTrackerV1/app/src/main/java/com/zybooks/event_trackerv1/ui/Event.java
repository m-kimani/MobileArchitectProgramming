package com.zybooks.event_trackerv1.ui;

public class Event {
    private int id;
    private int userId;
    private String title;
    private String date;
    private String time;
    private String description;
    private String reminder;

    public Event(int id, int userId, String title, String date, String time, String description, String reminder) {
        this.id = id;
        this.userId = userId;
        this.title = title;
        this.date = date;
        this.time = time;
        this.description = description;
        this.reminder = reminder;
    }

    public int getId() {
        return id;
    }

    public int getUserId() {
        return userId;
    }

    public String getTitle() {
        return title;
    }

    public String getDate() {
        return date;
    }

    public String getTime() {
        return time;
    }

    public String getDescription() {
        return description;
    }

    public String getReminder() {
        return reminder;
    }
}
