package com.zybooks.event_trackerv1.ui;

import android.Manifest;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Switch;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.zybooks.event_trackerv1.R;

public class SMSNotificationActivity extends AppCompatActivity {

    private static final int SMS_CODE = 100;
    private SwitchCompat smsNotificationsSwitch;
    private SharedPreferences prefs;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_smsnotification);
        // Hides the support action bar
        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }
        smsNotificationsSwitch = findViewById(R.id.sms_notification_switch);
        prefs = getSharedPreferences("settings", MODE_PRIVATE);

        boolean smsEnabled = prefs.getBoolean("sms_enabled", false);
        smsNotificationsSwitch.setChecked(smsEnabled);
        // Requests SMS permission if the switch is toggled on and sets sms enabled to false and alerts the user if toggled off
        smsNotificationsSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if(isChecked) {
                requestSmsPermission();
            } else {
                prefs.edit().putBoolean("sms_enabled", false).apply();
                Toast.makeText(this, "SMS notifications turned off", Toast.LENGTH_SHORT).show();
            }
        });
    }

    // Used to request permission for SMS notifications
    private void requestSmsPermission() {
        // If sms notification permission is already granted, enable sms and alert the user
        if(ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
            prefs.edit().putBoolean("sms_enabled", true).apply();
            Toast.makeText(this, "SMS notifications turned on", Toast.LENGTH_SHORT).show();
            // Else, request permission from the user
        } else {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, SMS_CODE);
        }
    }

    // Used to alert the user of the SMS permission results
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permission, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permission, grantResults);

        // Checks if the incoming request code matches the sms code
        if(requestCode == SMS_CODE) {
            // If so, if the result is permission granted, the switch is set to true and the user is alerted
            if(grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                prefs.edit().putBoolean("sms_enabled", true).apply();
                smsNotificationsSwitch.setChecked(true);
                Toast.makeText(this, "SMS permission granted", Toast.LENGTH_SHORT).show();
                // Else, the switch is toggled off and the user is alerted
            } else {
                prefs.edit().putBoolean("sms_enabled", false).apply();
                smsNotificationsSwitch.setChecked(false);
                Toast.makeText(this, "SMS permission denied. You will not receive SMS notifications.", Toast.LENGTH_SHORT).show();
            }
        }
    }
}