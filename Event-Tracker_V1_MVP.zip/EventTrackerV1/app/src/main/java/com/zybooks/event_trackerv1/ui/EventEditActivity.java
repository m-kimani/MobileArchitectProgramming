package com.zybooks.event_trackerv1.ui;

import android.Manifest;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Build;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;
import androidx.core.content.ContextCompat;

import com.zybooks.event_trackerv1.R;
import com.zybooks.event_trackerv1.ui.database.UserEventDatabase;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class EventEditActivity extends AppCompatActivity {
    private EditText titleInput;
    private EditText dateInput;
    private EditText timeInput;
    private EditText descriptionInput;
    private SwitchCompat reminderSwitch;
    private Button saveButton;
    private UserEventDatabase db;
    private int userId;
    private int eventId;
    private boolean isEditMode;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_event_edit);
        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }
        db = new UserEventDatabase(this);
        userId = getIntent().getIntExtra("USER_ID", -1);
        eventId = getIntent().getIntExtra("EVENT_ID", -1);
        isEditMode = eventId != -1;
        titleInput = findViewById(R.id.event_title_input);
        dateInput = findViewById(R.id.event_date_input);
        timeInput = findViewById(R.id.event_time_input);
        descriptionInput = findViewById(R.id.event_description_input);
        reminderSwitch = findViewById(R.id.event_reminder_switch);
        saveButton = findViewById(R.id.save_event_button);
        dateInput.setOnClickListener(v -> showDatePicker());
        timeInput.setOnClickListener(v -> showTimePicker());
        if (isEditMode) {
            loadEventData();
            saveButton.setText("Update Event");
        } else {
            saveButton.setText("Add Event");
        }
        saveButton.setOnClickListener(v -> saveEvent());
    }

    // Loads an event by its ID
    private void loadEventData() {
        Cursor cursor = db.getEventById(eventId);
        if (cursor.moveToFirst()) {
            titleInput.setText(cursor.getString(cursor.getColumnIndexOrThrow("title")));
            dateInput.setText(cursor.getString(cursor.getColumnIndexOrThrow("date")));
            timeInput.setText(cursor.getString(cursor.getColumnIndexOrThrow("time")));
            descriptionInput.setText(cursor.getString(cursor.getColumnIndexOrThrow("description")));
            String reminder = cursor.getString(cursor.getColumnIndexOrThrow("reminder"));
            reminderSwitch.setChecked(reminder.equals("On"));
        }
        cursor.close();
    }

    // Saves the edited or neew event
    private void saveEvent() {
        String title = titleInput.getText().toString();
        String date = dateInput.getText().toString();
        String time = timeInput.getText().toString();
        String description = descriptionInput.getText().toString();
        String reminder = reminderSwitch.isChecked() ? "On" : "Off";
        if (title.isEmpty() || date.isEmpty() || time.isEmpty()) {
            Toast.makeText(this, "Title, date, and time are required", Toast.LENGTH_SHORT).show();
            return;
        }

        if (isEditMode) {
            db.updateEvent(eventId, title, date, time, description, reminder);
            Toast.makeText(this, "Event updated", Toast.LENGTH_SHORT).show();
        } else {
            long result = db.addNewEvent(userId, title, date, time, description, reminder);
            if (result == -1) {
                Toast.makeText(this, "Event not saved", Toast.LENGTH_SHORT).show();
                return;
            }
            Toast.makeText(this, "Event added", Toast.LENGTH_SHORT).show();
        }

        SharedPreferences prefs = getSharedPreferences("settings", MODE_PRIVATE);
        boolean smsEnabled = prefs.getBoolean("sms_enabled", false);

        if (smsEnabled && ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
            // Sends the user an SMS notification if the destination is wired
            SmsManager smsManager = getSystemService(SmsManager.class);
            smsManager.sendTextMessage(
                    "8133614647",
                    null,
                    "Event alert: " + title + " has been added.",
                    null,
                    null
            );
            // Alert that message was sent
            Toast.makeText(
                    this,
                    "SMS alert sent for " + title,
                    Toast.LENGTH_SHORT).show();
        }
        finish();
    }

    // Shows the date picker in the event edit view
    private void showDatePicker() {
        Calendar calendar = Calendar.getInstance();
        DatePickerDialog dialog = new DatePickerDialog(
                this,
                (view, year, month, dayOfMonth) -> {
                    Calendar selectedDate = Calendar.getInstance();
                    selectedDate.set(year, month, dayOfMonth);
                    SimpleDateFormat formatter =
                            new SimpleDateFormat("MMMM d, yyyy", Locale.US);
                    dateInput.setText(formatter.format(selectedDate.getTime()));
                },

                calendar.get(Calendar.YEAR),
                calendar.get(Calendar.MONTH),
                calendar.get(Calendar.DAY_OF_MONTH)
        );

        dialog.show();

    }

    // Shows the time picker in the event edit view
    private void showTimePicker() {
        Calendar calendar = Calendar.getInstance();
        TimePickerDialog dialog = new TimePickerDialog(
                this,
                (view, hourOfDay, minute) -> {
                    Calendar selectedTime = Calendar.getInstance();
                    selectedTime.set(Calendar.HOUR_OF_DAY, hourOfDay);
                    selectedTime.set(Calendar.MINUTE, minute);
                    SimpleDateFormat formatter =
                            new SimpleDateFormat("h:mm a", Locale.US);
                    timeInput.setText(formatter.format(selectedTime.getTime()));
                },
                calendar.get(Calendar.HOUR_OF_DAY),
                calendar.get(Calendar.MINUTE),
                false
        );
        dialog.show();
    }
}
