package com.zybooks.event_trackerv1.ui.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class UserEventDatabase extends SQLiteOpenHelper {
    // Database details
    private static final String DB_NAME = "event-tracker-db";
    private static final int DB_VERSION = 2;
    // Database user table
    private static final String USERS = "users";
    private static final String USER_ID = "id";
    private static final String USER_ID_PK  = "userId";
    private static final String USERNAME = "username";
    private static final String PASSWORD = "password";
    // Database event table
    private static final String EVENTS = "events";
    private static final String EVENT_ID = "id";
    private static final String TITLE = "title";
    private static final String DATE = "date";
    private static final  String TIME = "time";
    private static final  String REMINDER = "reminder";
    private static final  String DESCRIPTION = "description";

    private static final String LOCATION = "location";

    public UserEventDatabase(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        String createUsersTable =
                "CREATE TABLE " + USERS + "(" +
                        USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
                        USERNAME + " TEXT UNIQUE," +
                        PASSWORD + " TEXT)";

        String createEventsTable =
                "CREATE TABLE " + EVENTS + "(" +
                        EVENT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
                        USER_ID_PK + " INTEGER," +
                        TITLE + " TEXT," +
                        DATE + " TEXT," +
                        TIME + " TEXT," +
                        DESCRIPTION + " TEXT," +
                        REMINDER + " TEXT," +
                        "FOREIGN KEY(userId) REFERENCES users(id))";

        db.execSQL(createUsersTable);
        db.execSQL(createEventsTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldDBVersion, int newDBVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + USERS );
        db.execSQL("DROP TABLE IF EXISTS " + EVENTS );
        onCreate(db);
    }

    // Registers a new user in the DB
    public boolean registerUser(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues vals = new ContentValues();
        vals.put(USERNAME, username);
        vals.put(PASSWORD, password);
        // Returns -1 on error
        long result = db.insert(USERS, null, vals);
        // Returns true if insert is successful
        return result != -1;
    }

    // Check if login credentials exist in db
    public boolean checkLogin(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + USERS + " WHERE username=? and password=?", new String[]{username, password});
        boolean userExists = cursor.getCount() > 0;

        cursor.close();
        return userExists;
    }

    public int getUserId(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(
                "SELECT id FROM users WHERE username=? AND password=?",
                new String[]{username, password}
        );
        int userId = -1;
        if (cursor.moveToFirst()) {
            userId = cursor.getInt(0);
        }
        cursor.close();
        return userId;
    }

    // Create a new event
    public long addNewEvent(int userId, String title, String date, String time, String description, String reminder) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues vals = new ContentValues();
        vals.put(USER_ID_PK, userId);
        vals.put(TITLE, title);
        vals.put(DATE, date);
        vals.put(TIME, time);
        vals.put(DESCRIPTION, description);
        vals.put(REMINDER, reminder);
        // Returns -1 on error
        return db.insert(EVENTS, null, vals);
        // Returns true if insert is successful
    }

    // Read all events in DB
    public Cursor getAllEvents(int userId) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM " + EVENTS + " WHERE userId=?", new String[]{String.valueOf(userId)});
    }

    // Delete event in DB
    public boolean deleteEvent(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        // Returns the number of wors successfully deleted
        int rows = db.delete(EVENTS, "id=?", new String[]{String.valueOf(id)});
        // Returns true if deletion successful
        return rows > 0;
    }

    public Cursor getEventById(int eventId){
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery(
                "SELECT * FROM events WHERE id = ?",
                new String[]{String.valueOf(eventId)}
        );
    }

    // Update an event
    public boolean updateEvent(int eventId, String title, String date, String time, String description, String reminder){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("title", title);
        values.put("date", date);
        values.put("time", time);
        values.put("description", description);
        values.put("reminder", reminder);
        int rowsUpdated = db.update(EVENTS, values, EVENT_ID + " = ?",
                new String[]{String.valueOf(eventId)}
        );
        return rowsUpdated > 0;
    }

}
