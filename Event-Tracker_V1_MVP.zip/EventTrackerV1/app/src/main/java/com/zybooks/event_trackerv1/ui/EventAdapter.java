package com.zybooks.event_trackerv1.ui;

import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.zybooks.event_trackerv1.R;
import com.zybooks.event_trackerv1.ui.database.UserEventDatabase;

import java.util.ArrayList;

public class EventAdapter extends RecyclerView.Adapter<EventAdapter.EventViewHolder> {
    private ArrayList<Event> events;
    private final UserEventDatabase db;
    private final Runnable refreshEventGrid;


    public EventAdapter(ArrayList<Event> events, UserEventDatabase db, Runnable refreshEventGrid) {
        this.events = events;
        this.db = db;
        this.refreshEventGrid = refreshEventGrid;
    }

    @NonNull
    @Override
    public EventViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.event_item, parent, false);
        return  new EventViewHolder(view);
    }

    // Binds event data to each card and sets click listeners
    @Override
    public void onBindViewHolder(@NonNull EventViewHolder holder, int position) {
        // Get the event based on the position
        Event event = events.get(position);

        // Set event card details
        holder.textTitle.setText("Title: " + event.getTitle());
        holder.textDate.setText("Date: " + event.getDate());
        holder.textTime.setText("Time: " + event.getTime());
        holder.textDescription.setText("Description: " + event.getDescription());
        holder.textReminder.setText("Reminder: " + event.getReminder());

        // Set the click listener for the event card so the event edit activity is started when clicked
        holder.itemView.setOnClickListener(view -> {
            Intent intent = new Intent(view.getContext(), EventEditActivity.class);
            intent.putExtra("USER_ID", event.getUserId());
            intent.putExtra("EVENT_ID", event.getId());
            view.getContext().startActivity(intent);
        });

        // Sets the on click listener for the delete button so the event deletes and the grid refreshes
        holder.deleteButton.setOnClickListener(view -> {
            db.deleteEvent(event.getId());
            refreshEventGrid.run();
        });
    }

    // Returns the number of total events in the user's event list
    @Override
    public int getItemCount() {
        return events.size();
    }

    // Holds references to the views inside each event card
    static class EventViewHolder extends RecyclerView.ViewHolder {
        TextView textTitle, textDate, textDescription, textTime, textReminder;
        Button deleteButton;

        public EventViewHolder(@NonNull View itemView) {
            super(itemView);
            textTitle = itemView.findViewById(R.id.event_title);
            textDate = itemView.findViewById(R.id.event_date);
            textTime = itemView.findViewById(R.id.time);
            textDescription = itemView.findViewById(R.id.event_description);
            textReminder = itemView.findViewById(R.id.event_reminder);
            deleteButton = itemView.findViewById(R.id.delete_button);
        }
    }
}



