package com.zybooks.event_trackerv1.ui;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.zybooks.event_trackerv1.R;
import com.zybooks.event_trackerv1.ui.database.UserEventDatabase;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Locale;
import android.content.Intent;

public class EventActivity extends AppCompatActivity {

    private RecyclerView recyclerViewEvents;
    private EventAdapter adapter;
    private UserEventDatabase db;
    private int userId;
    private Button newEventButton;
    private Button smsSettingsButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_event);
        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }
        db = new UserEventDatabase(this);
        userId = getIntent().getIntExtra("USER_ID", -1);
        recyclerViewEvents = findViewById(R.id.event_recycler_view);
        newEventButton = findViewById(R.id.new_event_button);
        smsSettingsButton = findViewById(R.id.sms_settings_button);

        smsSettingsButton.setOnClickListener(v -> {
            Intent intent = new Intent(EventActivity.this, SMSNotificationActivity.class);
            startActivity(intent);
        });
        newEventButton.setOnClickListener(v -> {
            Intent intent = new Intent(EventActivity.this, EventEditActivity.class);
            intent.putExtra("USER_ID", userId);
            startActivity(intent);
        });
        recyclerViewEvents.setLayoutManager(new GridLayoutManager(this, 2));
        loadEvents();
    }

    // Loads the events from the database and displays them on the recycler view
    private void loadEvents() {
        ArrayList<Event> eventList = new ArrayList<>();
        // Retrieves the events by user id from the database
        Cursor cursor = db.getAllEvents(userId);
        // Start adding events to the list if the first event is present
        if (cursor.moveToFirst()) {
            // Add each event to the event list
            do {
                int id = cursor.getInt(cursor.getColumnIndexOrThrow("id"));
                int eventUserId = cursor.getInt(cursor.getColumnIndexOrThrow("userId"));
                String title = cursor.getString(cursor.getColumnIndexOrThrow("title"));
                String date = cursor.getString(cursor.getColumnIndexOrThrow("date"));
                String time = cursor.getString(cursor.getColumnIndexOrThrow("time"));
                String description = cursor.getString(cursor.getColumnIndexOrThrow("description"));
                String reminder = cursor.getString(cursor.getColumnIndexOrThrow("reminder"));
                eventList.add(new Event(id, eventUserId, title, date, time, description, reminder));

            } while (cursor.moveToNext());
        }
        cursor.close();
        // Add the event list to the adapter
        adapter = new EventAdapter(eventList, db, this::loadEvents);
        // Set the new adapter as the recycler view adapter to load the events
        recyclerViewEvents.setAdapter(adapter);
    }


    // Refreshes grid after adding an event
    @Override
    protected void onResume() {
        super.onResume();
        loadEvents();
    }
}